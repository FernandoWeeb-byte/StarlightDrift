Padr�o duplo - 2 padr�es opostos, feitos para serem executados ao mesmo tempo por 2 inimigos diferentes
Padr�o longo - Padr�o de inimigo atravessando toda a tela
Padr�o zig - 2 padr�es de zigue zague em posi��es x diferentes